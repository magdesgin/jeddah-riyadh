import React, { useEffect, useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import Reveal from '@/components/Reveal';
import Seo from '@/components/Seo';
import {
	Accordion,
	AccordionContent,
	AccordionItem,
	AccordionTrigger,
} from '@/components/ui/accordion';
import {
	Phone,
	MessageCircle,
	Truck,
	Route,
	ShieldCheck,
	MapPin,
	BadgeCheck,
	Menu,
	X,
	ChevronLeft,
	ArrowUp,
	LifeBuoy,
	Navigation,
	Package,
	Star,
	Timer,
	CircleCheck,
	HandCoins,
	Layers,
	Lock,
	Car,
	Warehouse,
	Gauge,
	Banknote,
	Clock3,
	Shield,
	Wrench,
} from 'lucide-react';

const PHONE_DISPLAY = '0550283132';
const PHONE_TEL = 'tel:+966550283132';
const WHATSAPP_URL =
	'https://wa.me/966550283132?text=' +
	encodeURIComponent(
		'مرحباً، أحتاج سطحة من جدة إلى الرياض لنقل سيارتي. أريد معرفة السعر والمسافة.',
	);

const LOGO_URL =
	'https://horizons-cdn.hostinger.com/4ad68a79-6f50-4e0c-957e-fac7e06af516/9d69835d2e57d4c8288ba1ea3041d7ba.jpg';

const IMG = {
	front:
		'https://horizons-cdn.hostinger.com/4ad68a79-6f50-4e0c-957e-fac7e06af516/e25b2092aa69c3b30d59ad5e45d9ccca.jpg',
	m4:
		'https://horizons-cdn.hostinger.com/4ad68a79-6f50-4e0c-957e-fac7e06af516/1e62e2ac567e1dabab63f76e73b192b6.jpg',
	double:
		'https://horizons-cdn.hostinger.com/4ad68a79-6f50-4e0c-957e-fac7e06af516/b5c4a0bbb6231b8e7173191f70f7a0ed.jpg',
	box:
		'https://horizons-cdn.hostinger.com/4ad68a79-6f50-4e0c-957e-fac7e06af516/fd9e1c152753a9f6315bf6aa83a374c2.jpg',
	lambo:
		'https://horizons-cdn.hostinger.com/4ad68a79-6f50-4e0c-957e-fac7e06af516/a3d2dfa511ccc0824df144fcee1b369e.jpg',
	orange:
		'https://horizons-cdn.hostinger.com/4ad68a79-6f50-4e0c-957e-fac7e06af516/fb07854d5a7a954444a74c79504cac52.png',
	lime:
		'https://horizons-cdn.hostinger.com/4ad68a79-6f50-4e0c-957e-fac7e06af516/a9fc547c41bea6ef8658ceace721ea45.jpg',
	vip:
		'https://horizons-cdn.hostinger.com/4ad68a79-6f50-4e0c-957e-fac7e06af516/eccbc85c1dae70f4bb168db430a6fe0b.jpg',
	night:
		'https://horizons-cdn.hostinger.com/4ad68a79-6f50-4e0c-957e-fac7e06af516/a5e911fadad53f71c47679c5d5ac8fbf.jpg',
	hero3d:
		'https://horizons-cdn.hostinger.com/4ad68a79-6f50-4e0c-957e-fac7e06af516/b53a06986681da7f492ee87a8c99883b.png',
};

const HERO_IMG = IMG.hero3d;
const TRANSPORT_IMG = IMG.lambo;

const NAV_LINKS = [
	{ href: '#services', label: 'أنواع السطحة' },
	{ href: '#pricing', label: 'الأسعار' },
	{ href: '#areas', label: 'أحياء جدة والرياض' },
	{ href: '#cars', label: 'أنواع السيارات' },
	{ href: '#transport', label: 'النقل بين المدن' },
	{ href: '#faq', label: 'الأسئلة' },
	{ href: '#contact', label: 'حجز' },
];

const SERVICES = [
	{
		icon: Layers,
		title: 'سطحة هيدروليك من جدة الى الرياض',
		text: 'سطحة هيدروليك (فل داون) بسطح متحرك كامل — تحميل وتنزيل السيارة دون سحب العجلات على الإسفلت. الأنسب للسيارات المنخفضة، الدفع الرباعي، والسيارات الحديثة على خط جدة الرياض.',
	},
	{
		icon: Truck,
		title: 'سطحة عادية من جدة الى الرياض',
		text: 'سطحة عادية سريعة لنقل السيارات بين جدة والرياض: أعطال، حوادث، ونقل سيارات مستعملة وجديدة مع وصول على مدار الساعة 24/7.',
	},
	{
		icon: Lock,
		title: 'سطحة مغلقة من جدة الى الرياض',
		text: 'سطحة مغلقة محمية من جدة إلى الرياض — حماية كاملة من الغبار والمطر والحرارة، مثالية للسيارات الفاخرة والرياضية والمزادات وسيارات الوكالات. تثبيت احترافي داخل الصندوق يحافظ على هيكل السيارة طوال مسافة 950 كم.',
	},
	{
		icon: Navigation,
		title: 'نقل سيارات بين جدة والرياض',
		text: 'نقل وشحن السيارات بين جدة والرياض في الاتجاهين — من جدة إلى الرياض ومن الرياض إلى جدة بسعر ثابت حسب الكيلومتر والوجهة.',
	},
	{
		icon: Package,
		title: 'شحن سيارات من جدة الى الرياض',
		text: 'شحن سيارات لمسافة طويلة (نحو 950 كم) بأسعار ثابتة حسب الكيلومتر، جداول واضحة ومتابعة مباشرة حتى باب التسليم في الرياض.',
	},
	{
		icon: LifeBuoy,
		title: 'سطحة فورية من جدة الى الرياض',
		text: 'سطحة فورية لنقل السيارات المعطلة والمصدومة وغير العاملة من جدة إلى الرياض — استجابة سريعة 24 ساعة على مدار الساعة.',
	},
];

const PRICE_PLANS = [
	{
		type: 'سطحة عادية',
		from: '1000 – 1100 ريال',
		km: '≈ 950 كم',
		time: '18–20 ساعة',
		note: 'سطحة عادية من جدة الى الرياض — الأنسب للسيارات العادية والمستعملة',
		features: [
			'نقل سيارة من جدة الى الرياض بسعر مناسب',
			'تحميل وتثبيت احترافي',
			'تأمين على السيارة أثناء النقل',
			'متابعة مباشرة حتى التسليم',
		],
	},
	{
		type: 'سطحة هيدروليك (فل داون)',
		from: '1100 – 1300 ريال',
		km: '≈ 950 كم',
		time: '18–20 ساعة',
		note: 'سطحة هيدروليك من جدة الى الرياض — للسيارات المنخفضة والحديثة والدفع الرباعي',
		features: [
			'سطح متحرك كامل بدون سحب العجلات',
			'مناسبة للسيارات الفاخرة والرياضية',
			'تثبيت احترافي مؤمّن',
			'نقل آمن من الباب إلى الباب',
		],
		popular: true,
	},
	{
		type: 'سطحة مغلقة',
		from: '1800 – 2000 ريال',
		km: '≈ 950 كم',
		time: '18–20 ساعة',
		note: 'سطحة مغلقة من جدة الى الرياض — حماية كاملة للسيارات الفاخرة والجديدة',
		features: [
			'صندوق مغلق يحمي من الغبار والمطر',
			'الأنسب لسيارات الوكالات والمزادات',
			'خصوصية وأمان أعلى',
			'تأمين شامل حتى التسليم',
		],
	},
];

const JEDDAH_AREAS = [
	'الحمدانية',
	'أبحر',
	'الصفا',
	'النسيم',
	'المروة',
	'النزهة',
	'السلامة',
	'الروضة',
	'الشفا',
	'شمال جدة',
	'جنوب جدة',
	'شرق جدة',
	'غرب جدة',
	'وسط جدة',
];

const RIYADH_AREAS = [
	'شمال الرياض',
	'جنوب الرياض',
	'شرق الرياض',
	'غرب الرياض',
	'وسط الرياض',
	'النسيم الرياض',
	'الشفا الرياض',
	'الروضة الرياض',
	'الملقا',
	'النرجس',
	'الياسمين',
	'العليا',
];

const CAR_TYPES = [
	{
		icon: Car,
		title: 'سيارات فاخرة',
		text: 'سطحة سيارات فارهة من جدة الى الرياض — نقل آمن ومؤمّن للسيارات الفاخرة بسطحة هيدروليك أو مغلقة.',
	},
	{
		icon: Gauge,
		title: 'سيارات رياضية',
		text: 'سطحة سيارات رياضية من جدة الى الرياض — سطحة هيدروليك للسيارات المنخفضة دون خدش الشاصي.',
	},
	{
		icon: Package,
		title: 'سيارات جديدة',
		text: 'سطحة نقل سيارات جديدة من جدة الى الرياض — سيارات الوكالات بسطحة مغلقة محمية.',
	},
	{
		icon: Wrench,
		title: 'سيارات تالفة',
		text: 'سطحة نقل سيارات تالفة من جدة الى الرياض — نقل السيارات المصطومة والمتضررة بأمان.',
	},
	{
		icon: Lock,
		title: 'سيارات بدون تشغيل',
		text: 'سطحة نقل سيارة لا تعمل من جدة الى الرياض — تحميل بالونش أو الهيدروليك دون الحاجة لتشغيلها.',
	},
	{
		icon: Navigation,
		title: 'دفع رباعي وجيب',
		text: 'سطحة نقل جيب ودفع رباعي من جدة الى الرياض — سطحة هيدروليك تتحمّل السيارات الثقيلة.',
	},
];

const FAQS = [
	{
		q: 'كم سعر السطحة من جدة الى الرياض؟',
		a: 'سعر السطحة من جدة الى الرياض يبدأ من 1000 ريال للسطحة العادية، و1100 ريال للسطحة الهيدروليك (فل داون)، و1800 ريال للسطحة المغلقة. السعر النهائي يعتمد على نوع السطحة وحجم السيارة والمسافة (نحو 950 كم). نثبت السعر قبل التحميل عبر الاتصال أو واتساب 0550283132.',
	},
	{
		q: 'كم تكلفة نقل سيارة من جدة الى الرياض؟',
		a: 'تكلفة نقل السيارة من جدة إلى الرياض تتراوح بين 1000 و2000 ريال حسب نوع السطحة: عادية، هيدروليك، أو مغلقة. المسافة تقريباً 950 كم ومدة الشاحنة 18–20 ساعة. السعر يشمل التحميل والتثبيت والتأمين حتى التسليم في الرياض.',
	},
	{
		q: 'كم تستغرق السطحة من جدة الى الرياض؟',
		a: 'تستغرق السطحة من جدة إلى الرياض حوالي 18–20 ساعة على طريق سريع بطول نحو 950 كم. غالباً يتم التسليم خلال 18–20 ساعة من الانطلاق حسب حالة الطريق والوقت.',
	},
	{
		q: 'هل توجد سطحة من جدة الى الرياض 24 ساعة؟',
		a: 'نعم. نوفر سطحة جدة الرياض 24 ساعة على مدار الساعة 24/7 بما في ذلك الإجازات والأعياد. سطحة فورية من جدة الى الرياض اليوم — اتصل أو راسل واتساب 0550283132 في أي وقت للحجز الفوري.',
	},
	{
		q: 'كيف احجز سطحة من جدة الى الرياض؟',
		a: 'لحجز سطحة من جدة الى الرياض اتصل مباشرة على 0550283132 أو راسلنا واتساب. أخبرنا بنوع السيارة وموقعك في جدة (مثل الحمدانية، أبحر، الصفا، النسيم) ووجهتك في الرياض لنحسب السعر والمسافة ونرسل السطحة فوراً. بعدها تختار نوع السطحة، نحمّل السيارة بتوثيق بالصور وتثبيت احترافي، ونسلّمها عند بابك في الرياض.',
	},
	{
		q: 'ما ارخص سطحة من جدة الى الرياض؟',
		a: 'أرخص سطحة من جدة الى الرياض تبدأ من 1000 ريال للسطحة العادية. نقدم أسعاراً منافسة وعروضاً حسب المسافة بدون رسوم خفية. للحصول على أرخص سعر نقل سيارة من جدة للرياض تواصل معنا واتساب لنرسل لك عرض السعر المناسب.',
	},
	{
		q: 'هل توجد سطحة هيدروليك من جدة الى الرياض؟',
		a: 'نعم. نوفر سطحة هيدروليك من جدة الى الرياض (فل داون) بسطح متحرك كامل يحمّل السيارة دون سحب العجلات — مثالية للسيارات المنخفضة والحديثة والدفع الرباعي والسيارات الفاخرة والرياضية. السعر يبدأ من 1100 ريال.',
	},
	{
		q: 'هل يمكن نقل سيارة مصدومة من جدة الى الرياض؟',
		a: 'نعم. ننقل السيارات المصطومة والمتضررة من جدة إلى الرياض بسطحة هيدروليك أو ونش حسب حالة السيارة. سطحة سيارة مصدومة من جدة الى الرياض تتم بتحميل آمن دون زيادة الضرر، مع توثيق بالصور قبل التحميل.',
	},
	{
		q: 'هل توجد سطحة مغلقة لنقل السيارات من جدة الى الرياض؟',
		a: 'نعم. سطحة مغلقة من جدة الى الرياض تحمي سيارتك داخل صندوق مغلق من الغبار والمطر والحرارة أثناء النقل. الأنسب للسيارات الفاخرة والرياضية والجديدة وسيارات الوكالات والمزادات. السعر يبدأ من 1800 ريال.',
	},
	{
		q: 'ما افضل شركة نقل سيارات من جدة الى الرياض؟',
		a: 'نحن أفضل شركة سطحة من جدة الى الرياض بفضل خبرة +15 سنة، أسعار حسب المسافة، أسطول هيدروليك ومغلق، نقل آمن مؤمّن، وخدمة عملاء 24 ساعة. توثيق بالصور، تثبيت احترافي، ومحضر استلام عند التسليم.',
	},
	{
		q: 'هل سعر السطحة يشمل البنزين؟',
		a: 'نعم. سعر السطحة من جدة الى الرياض شامل كامل تكاليف الرحلة: البنزين، أجرة السائق، التحميل والتنزيل، والتأمين على السيارة. لا توجد رسوم خفية بعد الاتفاق — السعر ثابت قبل الانطلاق.',
	},
	{
		q: 'هل يمكن نقل سيارة لا تعمل من جدة الى الرياض؟',
		a: 'نعم. ننقل السيارات التي لا تعمل (بدون تشغيل) من جدة الى الرياض بسطحة هيدروليك أو ونش يقوم بتحميل السيارة دون الحاجة لتشغيلها. سطحة نقل سيارة خربانة أو عطلانة من جدة الى الرياض متاحة 24/7.',
	},
	{
		q: 'هل توجد خدمة نقل سيارات من الباب الى الباب؟',
		a: 'نعم. خدمة نقل سيارات من الباب الى الباب من جدة إلى الرياض — نستلم السيارة من موقعك في جدة (أي حي: الحمدانية، أبحر، الصفا، النسيم، المروة، النزهة، السلامة، الروضة) ونسلّمها عند بابك في الرياض.',
	},
	{
		q: 'هل تنقلون سيارة من الرياض الى جدة؟',
		a: 'نعم. نوفر سطحة من الرياض الى جدة بنفس الخدمة والأسعار — نقل سيارة من الرياض الى جدة، سطحة هيدروليك الرياض جدة، سطحة مغلقة الرياض جدة، وسطحة فل داون الرياض جدة. الاتجاهين متاحان 24/7 على نفس المسافة 950 كم بسعر يبدأ من 1000 ريال.',
	},
	{
		q: 'ما الفرق بين السطحة العادية والهيدروليك والمغلقة على خط جدة الرياض؟',
		a: 'السطحة العادية مناسبة للسيارات العادية والمستعملة بسعر من 1000 ريال. السطحة الهيدروليك (فل داون) تحمّل السيارة دون سحب العجلات — للسيارات المنخفضة والحديثة من 1100 ريال. السطحة المغلقة تضيف صندوقاً محمياً للسيارات الفاخرة والجديدة من 1800 ريال.',
	},
	{
		q: 'هل تنقلون سيارات الأفراد والشركات من جدة الى الرياض؟',
		a: 'نعم. ننقل سيارات الأفراد والشركات والوكالات من جدة الى الرياض بنفس الجودة والأمان. سواء كنت فرداً ينقل سيارته الشخصية أو شركة تحتاج نقل أسطول أو سيارة وكالة، نوفر سطحة هيدروليك ومغلقة بسعر ثابت حسب المسافة ونوع السيارة.',
	},
	{
		q: 'هل النقل من جدة الى الرياض مؤمّن؟',
		a: 'نعم. جميع عمليات نقل وشحن السيارات من جدة الى الرياض مؤمّنة. نلتقط صوراً قبل التحميل، نثبّت السيارة بأحزمة ومعدات معتمدة، ونسلّمها بمحضر استلام واضح بنفس الحالة. نقل سيارات آمن مع تأمين شامل حتى التسليم في الرياض.',
	},
	{
		q: 'كيف أتواصل معكم لحجز سطحة من جدة الى الرياض؟',
		a: 'لحجز سطحة من جدة الى الرياض اتصل مباشرة على 0550283132 أو راسلنا واتساب في أي وقت. خدمة العملاء متاحة 24 ساعة للحجز الفوري والاستفسار عن الأسعار. نقدم اتصالاً مباشراً ورداً سريعاً على مدار الساعة 24/7.',
	},
	{
		q: 'هل توفرون سطحة ونش لنقل السيارات من جدة الى الرياض؟',
		a: 'نعم. نوفر سطحة ونش لنقل السيارات التي لا تعمل أو المتعطلة أو المصطومة من جدة الى الرياض. الونش والسطحة الهيدروليك يقومان بتحميل السيارة دون الحاجة لتشغيلها، مع توثيق بالصور وتثبيت احترافي مؤمّن حتى التسليم.',
	},
];

function Header() {
	const [scrolled, setScrolled] = useState(false);
	const [open, setOpen] = useState(false);

	useEffect(() => {
		const onScroll = () => setScrolled(window.scrollY > 16);
		onScroll();
		window.addEventListener('scroll', onScroll, { passive: true });
		return () => window.removeEventListener('scroll', onScroll);
	}, []);

	return (
		<header
			className={`header-3d fixed inset-x-0 top-0 z-50 transition-all duration-300 ${
				scrolled ? 'header-3d-scrolled py-1.5' : 'py-2'
			}`}
		>
			<div className="mx-auto flex w-full max-w-6xl items-center justify-between gap-3 px-4 sm:px-6">
				<Link to="/" className="flex min-w-0 items-center gap-2.5" aria-label="سطحة من جدة الى الرياض">
				<span className="logo-round-3d inline-flex shrink-0 items-center">
					<img
						src={LOGO_URL}
						alt="سطحة من جدة الى الرياض — Jeddah Riyadh"
						className="h-10 w-auto max-w-[44vw] object-contain object-center sm:h-11 sm:max-w-[200px] lg:h-12 lg:max-w-[240px]"
						width={840}
						height={472}
					/>
				</span>
				<span className="flex min-w-0 flex-col font-display text-sm font-extrabold leading-tight text-foreground sm:text-base">
					<span className="truncate">سطحة جدة</span>
					<span className="truncate text-primary">إلى الرياض</span>
				</span>
			</Link>

				<nav className="hidden items-center gap-5 xl:flex" aria-label="التنقل الرئيسي">
					{NAV_LINKS.map((link, i) => (
						<a
							key={link.href}
							href={link.href}
							className={`text-sm font-medium transition-colors hover:text-primary ${
								i === 0 ? 'text-primary' : 'text-foreground/80'
							}`}
						>
							{link.label}
						</a>
					))}
				</nav>

				<div className="flex shrink-0 items-center gap-2 sm:gap-2.5">
					<a
						href={PHONE_TEL}
						className="btn-glossy-icon inline-flex h-9 w-9 items-center justify-center rounded-lg transition-transform active:scale-[0.98]"
						aria-label="اتصل الآن"
					>
						<Phone className="h-4 w-4" strokeWidth={2.4} />
					</a>
					<a
						href={WHATSAPP_URL}
						target="_blank"
						rel="noopener noreferrer"
						className="btn-wa-glossy inline-flex h-9 w-9 items-center justify-center rounded-lg transition-transform active:scale-[0.98]"
						aria-label="واتساب"
					>
						<MessageCircle className="h-4 w-4" strokeWidth={2.4} />
					</a>
					<button
						type="button"
						onClick={() => setOpen(!open)}
						className="flex h-10 w-10 items-center justify-center rounded-md border border-border text-foreground xl:hidden"
						aria-label={open ? 'إغلاق القائمة' : 'فتح القائمة'}
					>
						{open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
					</button>
				</div>
			</div>

			{open && (
				<nav
					className="mx-4 mt-2 rounded-xl border border-border bg-white p-3 shadow-lg xl:hidden"
					aria-label="قائمة الجوال"
				>
					{NAV_LINKS.map((link) => (
						<a
							key={link.href}
							href={link.href}
							onClick={() => setOpen(false)}
							className="block rounded-lg px-4 py-3 text-sm font-medium text-foreground/80 transition-colors hover:bg-muted hover:text-primary"
						>
							{link.label}
						</a>
					))}
					<a
						href={PHONE_TEL}
						className="btn-coral mt-2 flex items-center justify-center gap-2 rounded-md px-4 py-3 text-sm font-bold"
					>
						<Phone className="h-4 w-4" strokeWidth={2.4} />
						اتصل الآن
					</a>
				</nav>
			)}
		</header>
	);
}

function Hero() {
	return (
		<section
			id="home"
			className="relative flex min-h-[100dvh] items-center overflow-hidden bg-[hsl(210_40%_97%)] pt-20"
		>
			<div
				className="pointer-events-none absolute -left-24 top-24 h-72 w-72 rounded-full bg-primary/10 blur-3xl"
				aria-hidden="true"
			/>
			<div
				className="pointer-events-none absolute bottom-10 right-0 h-80 w-80 rounded-full bg-accent/15 blur-3xl"
				aria-hidden="true"
			/>

			<div className="relative z-10 mx-auto grid w-full max-w-6xl items-center gap-10 px-4 py-16 sm:px-6 lg:grid-cols-2 lg:gap-6 lg:py-10">
				<div className="order-2 lg:order-1">
					<Reveal y={20}>
						<p className="mb-4 inline-flex items-center gap-2 rounded-full border border-primary/20 bg-white px-4 py-1.5 text-xs font-bold text-primary shadow-sm">
							<span className="h-2 w-2 animate-pulse rounded-full bg-primary" />
							سطحة هيدروليك · مغلقة · نقل بين جدة والرياض 24/7
						</p>
						<h1 className="font-display text-4xl font-extrabold uppercase leading-[1.2] tracking-wide text-foreground sm:text-5xl lg:text-[3.15rem]">
							سطحة من <span className="gradient-mark">جدة</span>
							<br />
							إلى الرياض 24 ساعة
						</h1>
					</Reveal>

					<Reveal y={24} delay={0.1}>
						<p className="mt-6 max-w-lg text-base font-semibold leading-8 text-foreground">
							سطحة نقل سيارات من جدة الى الرياض: سطحة عادية، سطحة هيدروليك (فل داون)،
							وسطحة مغلقة — نقل وشحن السيارات بين جدة والرياض بسعر يبدأ من 1000 ريال،
							نقل آمن مؤمّن من الباب إلى الباب على مدار الساعة.
						</p>
					</Reveal>

					<Reveal y={24} delay={0.18}>
						<ul className="mt-6 space-y-2.5 text-[15px] font-light text-muted-foreground">
							{[
								'سطحة جدة الرياض 24/7 — حجز فوري اليوم',
								'سطحة هيدروليك ومغلقة لنقل السيارات الفاخرة والرياضية',
								'سعر ثابت حسب المسافة (950 كم) — من 1000 ريال بدون رسوم خفية',
								'نقل آمن مؤمّن: توثيق بالصور، تثبيت احترافي، وخبرة +15 سنة',
							].map((item) => (
								<li key={item} className="flex items-start gap-2.5">
									<span className="mt-1.5 inline-block h-0 w-0 border-y-[5px] border-y-transparent border-l-[8px] border-l-primary" />
									{item}
								</li>
							))}
						</ul>
					</Reveal>

					<Reveal y={24} delay={0.28}>
						<div className="mt-9 flex flex-wrap items-center gap-3">
							<a
								href={WHATSAPP_URL}
								target="_blank"
								rel="noopener noreferrer"
								className="btn-outline-coral inline-flex min-h-[50px] items-center gap-2 px-7 text-base font-light transition-colors active:scale-[0.98]"
							>
								<MessageCircle className="h-4 w-4" strokeWidth={2.2} />
								عرض سعر واتساب
							</a>
						</div>
						<p className="mt-4 text-sm font-bold text-primary" dir="ltr">
							{PHONE_DISPLAY}
						</p>
					</Reveal>
				</div>

				<div className="order-1 relative depth-3d lg:order-2">
					<div
						className="hero-blob absolute -left-8 -top-6 h-[92%] w-[88%] rounded-[0_0_0_42%] sm:-left-4 lg:left-8 lg:top-0 lg:h-full lg:w-[95%] lg:rounded-[48%_0_0_48%/60%_0_0_40%]"
						aria-hidden="true"
					/>
					<div
						className="absolute -left-2 top-10 h-40 w-40 rounded-full bg-white/25 blur-sm lg:left-4"
						aria-hidden="true"
					/>
					<div
						className="absolute bottom-16 left-0 h-28 w-28 rounded-full bg-orange-300/35 lg:left-10"
						aria-hidden="true"
					/>
					<div className="relative z-10 mx-auto max-w-lg float-3d lg:max-w-none">
						<div className="glass-3d shine-sweep overflow-hidden rounded-[2rem] p-4 sm:p-5">
							<img
								src={HERO_IMG}
								alt="سطحة هيدروليك جاهزة لنقل السيارات من جدة إلى الرياض"
								className="aspect-[16/10] w-full object-contain drop-shadow-2xl"
								loading="eager"
								width={800}
								height={500}
							/>
						</div>
						<div className="absolute -bottom-4 right-4 hidden rounded-2xl border border-white/60 bg-white/90 px-4 py-3 shadow-xl backdrop-blur sm:block">
							<p className="font-display text-sm font-extrabold text-foreground">
								جدة ⇄ الرياض
							</p>
							<p className="text-xs text-muted-foreground">950 كم · من 1000 ريال</p>
						</div>
					</div>
					<a
						href={PHONE_TEL}
						className="phone-glow absolute bottom-6 left-4 z-20 flex h-14 w-14 items-center justify-center rounded-full bg-white text-primary shadow-lg transition-colors hover:bg-primary hover:text-white lg:bottom-10 lg:left-0"
						aria-label="اتصل الآن"
					>
						<Phone className="h-5 w-5" strokeWidth={2.4} />
					</a>
				</div>
			</div>
		</section>
	);
}

function Services() {
	return (
		<section id="services" className="relative scroll-mt-24 bg-white py-24 sm:py-28">
			<div className="pointer-events-none absolute left-8 top-20 h-3 w-14 rotate-[-18deg] rounded-sm bg-gradient-to-r from-primary to-accent" aria-hidden="true" />
			<div className="mx-auto w-full max-w-6xl px-4 sm:px-6">
				<Reveal y={24}>
					<div className="mx-auto max-w-2xl text-center">
						<h2 className="font-display text-3xl font-extrabold text-foreground sm:text-4xl">
							أنواع <span className="gradient-mark">السطحة</span> من جدة إلى الرياض
						</h2>
						<p className="mt-4 leading-8 text-muted-foreground">
							سطحة عادية، سطحة هيدروليك (فل داون)، سطحة مغلقة، ونقل سيارات بين جدة
							والرياض — اختر ما يناسب سيارتك وميزانيتك
						</p>
					</div>
				</Reveal>

				<div className="mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
					{SERVICES.map((service, i) => {
						const Icon = service.icon;
						return (
							<Reveal key={service.title} y={28} delay={0.05 * i}>
								<article className="card-3d group h-full overflow-hidden border border-border">
									<div className="relative aspect-[16/10] overflow-hidden bg-gradient-to-br from-muted to-white">
										<img
											src={[IMG.m4, IMG.front, IMG.box, IMG.lambo, IMG.double, IMG.lime][i % 6]}
											alt={`${service.title} — سطحة جدة الرياض`}
											className="h-full w-full object-contain p-2 transition-transform duration-500 group-hover:scale-105"
											loading="lazy"
										/>
										<span className="orb-glow icon-pop absolute bottom-0 left-1/2 flex h-12 w-12 -translate-x-1/2 translate-y-1/2 items-center justify-center text-white transition-transform duration-300 group-hover:scale-110">
											<Icon className="h-5 w-5" strokeWidth={2.2} />
										</span>
									</div>
									<div className="px-6 pb-7 pt-10 text-center">
										<h3 className="font-display text-lg font-extrabold text-foreground">
											{service.title}
										</h3>
										<p className="mt-3 text-sm leading-7 text-muted-foreground">
											{service.text}
										</p>
										<a
											href={PHONE_TEL}
											className="mt-4 inline-flex items-center gap-1.5 text-sm font-medium text-primary transition-colors hover:text-foreground"
										>
											اطلب الخدمة
											<ChevronLeft className="h-4 w-4" strokeWidth={2.4} />
										</a>
									</div>
								</article>
							</Reveal>
						);
					})}
				</div>
			</div>
		</section>
	);
}

function Pricing() {
	return (
		<section id="pricing" className="relative scroll-mt-24 bg-white py-24 sm:py-28">
			<div className="mx-auto w-full max-w-6xl px-4 sm:px-6">
				<Reveal y={24}>
					<div className="mx-auto max-w-2xl text-center">
						<h2 className="font-display text-3xl font-extrabold text-foreground sm:text-4xl">
							أسعار <span className="gradient-mark">السطحة</span> من جدة إلى الرياض
						</h2>
						<p className="mt-4 leading-8 text-muted-foreground">
							أسعار نقل السيارات من جدة إلى الرياض حسب نوع السطحة — مسافة الطريق نحو
							950 كم ومدة الشاحنة 18–20 ساعة. أرخص سطحة من جدة الى الرياض تبدأ من 1000 ريال
							بدون رسوم خفية. السعر النهائي ثابت قبل التحميل عبر الاتصال أو واتساب 0550283132.
						</p>
					</div>
				</Reveal>

				<div className="mt-12 grid gap-6 lg:grid-cols-3">
					{PRICE_PLANS.map((plan, i) => (
						<Reveal key={plan.type} y={24} delay={0.06 * i}>
							<article
								className={`card-3d relative flex h-full flex-col rounded-2xl border p-7 ${
									plan.popular
										? 'border-primary/50 ring-2 ring-primary/20'
										: 'border-border'
								}`}
							>
								{plan.popular && (
									<span className="absolute -top-3 right-6 rounded-full bg-primary px-4 py-1 text-xs font-bold text-white shadow">
										الأكثر طلباً
									</span>
								)}
								<div className="flex items-start justify-between gap-3">
									<div>
										<h3 className="font-display text-lg font-extrabold text-foreground">
											{plan.type}
										</h3>
										<p className="mt-1 text-xs text-muted-foreground">{plan.note}</p>
									</div>
									<span className="orb-glow flex h-10 w-10 shrink-0 items-center justify-center rounded-full text-white">
										<Banknote className="h-4 w-4" strokeWidth={2.2} />
									</span>
								</div>
								<div className="mt-5 flex flex-wrap gap-2">
									<span className="inline-flex items-center gap-1.5 rounded-full bg-muted px-3 py-1 text-xs font-bold text-foreground/80">
										<Route className="h-3.5 w-3.5 text-primary" strokeWidth={2.4} />
										{plan.km}
									</span>
									<span className="inline-flex items-center gap-1.5 rounded-full bg-muted px-3 py-1 text-xs font-bold text-foreground/80">
										<Clock3 className="h-3.5 w-3.5 text-primary" strokeWidth={2.4} />
										{plan.time}
									</span>
								</div>
								<ul className="mt-5 space-y-2.5">
									{plan.features.map((f) => (
										<li key={f} className="flex items-start gap-2 text-sm text-muted-foreground">
											<CircleCheck className="mt-0.5 h-4 w-4 shrink-0 text-primary" strokeWidth={2.2} />
											{f}
										</li>
									))}
								</ul>
								<p className="mt-auto pt-6 font-display text-3xl font-black text-primary">
									{plan.from}
								</p>
								<a
									href={PHONE_TEL}
									className={`mt-5 inline-flex min-h-[46px] items-center justify-center gap-2 rounded-lg px-6 text-sm font-bold transition-transform active:scale-[0.98] ${
										plan.popular ? 'btn-coral' : 'btn-outline-coral'
									}`}
								>
									حجز سطحة
								</a>
							</article>
						</Reveal>
					))}
				</div>

				<Reveal y={20} delay={0.2}>
					<p className="mt-10 text-center text-sm leading-7 text-muted-foreground">
						أسعار السطحة المغلقة أعلى مقابل الحماية الكاملة. السعر يشمل البنزين وأجرة
						السائق والتحميل والتنزيل والتأمين — نثبت السعر قبل الانطلاق عبر{' '}
						<a href={PHONE_TEL} className="font-bold text-primary" dir="ltr">
							{PHONE_DISPLAY}
						</a>
						.
					</p>
				</Reveal>
			</div>
		</section>
	);
}

function Areas() {
	return (
		<section id="areas" className="relative scroll-mt-24 overflow-hidden bg-white py-24 sm:py-28">
			<div className="relative mx-auto w-full max-w-6xl px-4 sm:px-6">
				<Reveal y={24}>
					<div className="mx-auto max-w-2xl text-center">
						<h2 className="font-display text-3xl font-extrabold text-foreground sm:text-4xl">
							أحياء <span className="gradient-mark">جدة والرياض</span> التي نخدمها
						</h2>
						<p className="mt-4 leading-8 text-muted-foreground">
							سطحة من جدة الى الرياض من أي حي — استلام من بابك في جدة وتسليم عند بابك
							في الرياض. خدمة نقل سيارات من الباب الى الباب.
						</p>
					</div>
				</Reveal>

				<div className="mt-14 grid gap-6 lg:grid-cols-2">
					<Reveal y={28}>
						<div className="card-3d h-full border border-border bg-muted/50 p-7 sm:p-8">
							<h3 className="font-display flex items-center gap-2.5 text-lg font-extrabold text-foreground">
								<span className="orb-glow flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-white">
									<MapPin className="h-4 w-4" strokeWidth={2.2} />
								</span>
								أحياء جدة — نقطة الاستلام
							</h3>
							<p className="mt-2 text-xs leading-6 text-muted-foreground">
								سطحة من شمال وجنوب وشرق وغرب ووسط جدة إلى الرياض
							</p>
							<div className="mt-5 flex flex-wrap gap-2.5">
								{JEDDAH_AREAS.map((area) => (
									<span
										key={area}
										className="cursor-default rounded-full border border-border bg-white px-4 py-2 text-[13px] font-bold text-foreground/75 transition-all duration-200 hover:-translate-y-0.5 hover:border-primary/50 hover:text-primary"
									>
										{area}
									</span>
								))}
							</div>
						</div>
					</Reveal>

					<Reveal y={28} delay={0.1}>
						<div className="card-3d h-full border border-border bg-muted/50 p-7 sm:p-8">
							<h3 className="font-display flex items-center gap-2.5 text-lg font-extrabold text-foreground">
								<span className="orb-glow flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-white">
									<Navigation className="h-4 w-4" strokeWidth={2.2} />
								</span>
								أحياء الرياض — نقطة التسليم
							</h3>
							<p className="mt-2 text-xs leading-6 text-muted-foreground">
								تسليم السيارة عند بابك في أي حي بالرياض
							</p>
							<div className="mt-5 flex flex-wrap gap-2.5">
								{RIYADH_AREAS.map((area) => (
									<span
										key={area}
										className="cursor-default rounded-full border border-border bg-white px-4 py-2 text-[13px] font-bold text-foreground/75 transition-all duration-200 hover:-translate-y-0.5 hover:border-primary/50 hover:text-primary"
									>
										{area}
									</span>
								))}
							</div>
						</div>
					</Reveal>
				</div>
			</div>
		</section>
	);
}

function CarTypes() {
	return (
		<section id="cars" className="relative scroll-mt-24 overflow-hidden bg-muted py-24 sm:py-28">
			<div
				className="dot-grid pointer-events-none absolute left-8 top-24 h-36 w-36 rotate-45 opacity-70"
				aria-hidden="true"
			/>
			<div className="relative mx-auto w-full max-w-6xl px-4 sm:px-6">
				<Reveal y={24}>
					<div className="mx-auto max-w-2xl text-center">
						<h2 className="font-display text-3xl font-extrabold text-foreground sm:text-4xl">
							أنواع <span className="gradient-mark">السيارات</span> التي ننقلها
						</h2>
						<p className="mt-4 leading-8 text-muted-foreground">
							سطحة نقل سيارات من جدة الى الرياض لكل أنواع السيارات — فاخرة، رياضية،
							جديدة، تالفة، وبدون تشغيل
						</p>
					</div>
				</Reveal>

				<div className="mt-16 grid gap-10 sm:grid-cols-2 lg:grid-cols-3">
					{CAR_TYPES.map((item, i) => (
						<Reveal key={item.title} y={28} delay={0.06 * i}>
							<article className="group text-center">
								<span className="orb-glow icon-pop mx-auto flex h-20 w-20 items-center justify-center text-white transition-transform duration-300 group-hover:scale-105">
									<item.icon className="h-8 w-8" strokeWidth={1.8} />
								</span>
								<h3 className="font-display mt-6 text-lg font-extrabold text-foreground">
									{item.title}
								</h3>
								<p className="mt-3 text-sm leading-7 text-muted-foreground">
									{item.text}
								</p>
							</article>
						</Reveal>
					))}
				</div>
			</div>
		</section>
	);
}

function Transport() {
	return (
		<section id="transport" className="scroll-mt-24 bg-muted py-24 sm:py-28">
			<div className="mx-auto grid w-full max-w-6xl items-center gap-12 px-4 sm:px-6 lg:grid-cols-2">
				<Reveal y={28} className="order-2 lg:order-1">
					<div>
						<h2 className="font-display text-3xl font-extrabold leading-snug text-foreground sm:text-4xl">
							نقل سيارات بين <span className="gradient-mark">جدة والرياض</span>
						</h2>
						<p className="mt-5 leading-8 text-muted-foreground">
							سواء اشتريت من مزاد، انتقلت للعمل، أو تعطلت سيارتك — ننقل من جدة إلى
							الرياض ومن الرياض إلى جدة بمسافة محسوبة 950 كم، سعر ثابت، وسطحة هيدروليك أو
							مغلقة حسب طلبك. خدمة نقل سيارات بين المدن السعودية في الاتجاهين على مدار
							الساعة 24/7.
						</p>
						<ul className="mt-7 space-y-5">
							{[
								{
									title: 'حساب المسافة والسعر مسبقاً',
									text: 'نعتمد الكيلومترات (950 كم) ونوع السطحة لتحديد سعر نهائي قبل التحميل — من 1000 ريال في الاتجاهين.',
								},
								{
									title: 'تثبيت احترافي مؤمّن',
									text: 'أحزمة ومعدات معتمدة تحمي السيارة طوال الطريق من جدة إلى الرياض والعكس.',
								},
								{
									title: 'استلام وتسليم من الباب الى الباب',
									text: 'من موقعك في جدة إلى بابك في الرياض، ومن الرياض إلى جدة — نقل سيارات آمن وسريع.',
								},
							].map((item) => (
								<li key={item.title} className="flex items-start gap-4">
									<span className="orb-glow mt-0.5 flex h-11 w-11 shrink-0 items-center justify-center">
										<BadgeCheck className="h-5 w-5 text-white" strokeWidth={2.2} />
									</span>
									<div>
										<h3 className="font-display font-extrabold text-foreground">
											{item.title}
										</h3>
										<p className="mt-1 text-sm leading-7 text-muted-foreground">
											{item.text}
										</p>
									</div>
								</li>
							))}
						</ul>

						<div className="mt-7 rounded-2xl border border-border bg-white p-5">
							<h3 className="font-display text-base font-extrabold text-foreground">
								سطحة من الرياض الى جدة
							</h3>
							<p className="mt-2 text-sm leading-7 text-muted-foreground">
								نوفر سطحة من الرياض الى جدة بنفس الخدمة والأسعار — نقل سيارة من الرياض
								الى جدة، سطحة هيدروليك الرياض جدة، سطحة مغلقة الرياض جدة، وسطحة فل داون
								الرياض جدة بسعر يبدأ من 1000 ريال على نفس المسافة 950 كم.
							</p>
						</div>

						<a
							href={WHATSAPP_URL}
							target="_blank"
							rel="noopener noreferrer"
							className="btn-coral mt-9 inline-flex min-h-[50px] items-center gap-2.5 px-8 text-base font-medium transition-transform active:scale-[0.98]"
						>
							<MessageCircle className="h-5 w-5" strokeWidth={2.4} />
							احصل على عرض سعر حسب المسافة
						</a>
					</div>
				</Reveal>

				<Reveal y={28} delay={0.15} className="order-1 lg:order-2">
					<div className="relative depth-3d">
						<div className="overflow-hidden rounded-[2rem_0_2rem_0] shadow-xl ring-1 ring-black/5">
							<img
								src={TRANSPORT_IMG}
								alt="نقل وشحن سيارات من جدة إلى الرياض على الطريق السريع"
								className="aspect-video w-full object-cover transition-transform duration-700 hover:scale-105"
								loading="lazy"
							/>
						</div>
						<div className="price-chip absolute -bottom-5 right-6 border border-border px-5 py-4">
							<p className="font-display text-lg font-extrabold text-foreground" dir="ltr">
								950 كم
							</p>
							<p className="text-xs text-muted-foreground">
								مسافة جدة الرياض · 18–20 ساعة
							</p>
						</div>
					</div>
				</Reveal>
			</div>
		</section>
	);
}

function Faq() {
	return (
		<section id="faq" className="scroll-mt-24 bg-white py-24 sm:py-28">
			<div className="mx-auto w-full max-w-3xl px-4 sm:px-6">
				<Reveal y={24}>
					<div className="text-center">
						<h2 className="font-display text-3xl font-extrabold text-foreground sm:text-4xl">
							الأسئلة <span className="gradient-mark">الشائعة</span>
						</h2>
						<p className="mt-4 leading-8 text-muted-foreground">
							أسعار، مسافات، سطحة هيدروليك ومغلقة — إجابات واضحة عن سطحة جدة الرياض
						</p>
					</div>
				</Reveal>

				<Reveal y={28} delay={0.15}>
					<Accordion type="single" collapsible className="mt-12 space-y-4">
						{FAQS.map((faq, i) => (
							<AccordionItem
								key={faq.q}
								value={`item-${i}`}
								className="rounded-none border border-border bg-white px-6 data-[state=open]:border-primary/40"
							>
								<AccordionTrigger className="py-5 text-right text-base font-bold text-foreground hover:text-primary hover:no-underline [&[data-state=open]]:text-primary">
									{faq.q}
								</AccordionTrigger>
								<AccordionContent className="pb-6 text-sm leading-8 text-muted-foreground">
									{faq.a}
								</AccordionContent>
							</AccordionItem>
						))}
					</Accordion>
				</Reveal>
			</div>
		</section>
	);
}

function Contact() {
	const cards = [
		{
			icon: Phone,
			title: 'اتصل بنا',
			value: PHONE_DISPLAY,
			href: PHONE_TEL,
			note: 'سطحة جدة الرياض 24 ساعة',
			ltr: true,
		},
		{
			icon: MessageCircle,
			title: 'واتساب',
			value: 'عرض سعر فوري',
			href: WHATSAPP_URL,
			note: 'سعر حسب المسافة خلال دقائق',
			ltr: false,
		},
		{
			icon: Timer,
			title: 'ساعات العمل',
			value: '24 ساعة / 7 أيام',
			href: null,
			note: 'بما في ذلك الإجازات والأعياد',
			ltr: false,
		},
		{
			icon: MapPin,
			title: 'منطقة الخدمة',
			value: 'جدة ⇄ الرياض',
			href: null,
			note: 'نقل سيارات بين المدن في الاتجاهين',
			ltr: false,
		},
	];

	return (
		<section id="contact" className="scroll-mt-24 bg-muted py-24 sm:py-28">
			<div className="mx-auto w-full max-w-6xl px-4 sm:px-6">
				<Reveal y={24}>
					<div className="mx-auto max-w-2xl text-center">
						<h2 className="font-display text-3xl font-extrabold text-foreground sm:text-4xl">
							حجز <span className="gradient-mark">سطحة جدة الرياض</span>
						</h2>
						<p className="mt-4 leading-8 text-muted-foreground">
							اطلب سطحة هيدروليك أو سطحة مغلقة من جدة إلى الرياض — فريقنا جاهز 24/7
						</p>
					</div>
				</Reveal>

				<div className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
					{cards.map((card, i) => {
						const Wrapper = card.href ? 'a' : 'div';
						const linkProps = card.href
							? {
									href: card.href,
									...(card.href.startsWith('http')
										? { target: '_blank', rel: 'noopener noreferrer' }
										: {}),
								}
							: {};
						return (
							<Reveal key={card.title} y={28} delay={0.07 * i}>
								<Wrapper
									{...linkProps}
									className="card-3d block h-full border border-border bg-white p-7 text-center"
								>
									<span className="orb-glow mx-auto flex h-12 w-12 items-center justify-center">
										<card.icon className="h-5 w-5 text-white" strokeWidth={2.2} />
									</span>
									<h3 className="font-display mt-5 font-extrabold text-muted-foreground">
										{card.title}
									</h3>
									<p
										className="font-display mt-2 text-lg font-extrabold text-foreground"
										dir={card.ltr ? 'ltr' : 'rtl'}
									>
										{card.value}
									</p>
									<p className="mt-2 text-xs leading-6 text-muted-foreground">
										{card.note}
									</p>
								</Wrapper>
							</Reveal>
						);
					})}
				</div>
			</div>
		</section>
	);
}

function Footer() {
	return (
		<footer className="border-t border-border bg-slate-900 pb-24 pt-14 text-white md:pb-14">
			<div className="mx-auto w-full max-w-6xl px-4 sm:px-6">
				<div className="grid gap-10 md:grid-cols-3">
					<div>
						<Link to="/" className="inline-flex" aria-label="سطحة من جدة الى الرياض">
						<span className="logo-round-3d inline-flex items-center">
							<img
								src={LOGO_URL}
								alt="سطحة من جدة الى الرياض — Jeddah Riyadh"
								className="h-16 w-auto max-w-[240px] object-contain"
								width={840}
								height={472}
							/>
						</span>
					</Link>
						<p className="mt-5 max-w-sm text-sm leading-7 text-white/55">
							سطحة ونقل وشحن سيارات من جدة إلى الرياض والعكس. سطحة عادية، هيدروليك (فل
							داون)، وسطحة مغلقة — أسعار حسب المسافة (950 كم)، نقل آمن مؤمّن 24/7 من
							الباب إلى الباب.
						</p>
					</div>

					<nav aria-label="روابط سريعة">
						<h3 className="font-display font-extrabold">روابط سريعة</h3>
						<ul className="mt-5 space-y-3">
							{NAV_LINKS.map((link) => (
								<li key={link.href}>
									<a
										href={link.href}
										className="text-sm text-white/55 transition-colors hover:text-primary"
									>
										{link.label}
									</a>
								</li>
							))}
						</ul>
					</nav>

					<div>
						<h3 className="font-display font-extrabold">كلمات دلالية ووجهات</h3>
						<p className="mt-5 text-sm leading-8 text-white/55">
							سطحة من جدة الى الرياض · سطحة جدة الرياض · سطحة نقل سيارات من جدة الى
							الرياض · سطحة جدة الرياض 24 ساعة · سطحة هيدروليك من جدة الى الرياض ·
							سطحة مغلقة من جدة الى الرياض · سطحة فل داون جدة الرياض · سطحة عادية من
							جدة الى الرياض · نقل سيارة من جدة الى الرياض · شحن سيارات من جدة الى
							الرياض · ارخص سطحة من جدة الى الرياض · سطحة من جدة الى الرياض 1000 ريال ·
							سطحة من جدة الى الرياض 1100 ريال · سطحة من جدة الى الرياض 1800 ريال · سطحة من جدة الى الرياض 2000 ريال ·
							سطحة سيارات فارهة من جدة الى الرياض · سطحة سيارات رياضية من جدة الى الرياض ·
							سطحة نقل سيارات تالفة جدة الرياض · سطحة نقل سيارات بدون تشغيل جدة الرياض ·
							سطحة نقل جيب ودفع رباعي جدة الرياض · سطحة الحمدانية جدة الرياض · سطحة أبحر
							جدة الرياض · سطحة الصفا جدة الرياض · سطحة النسيم جدة الرياض · سطحة المروة
							جدة الرياض · سطحة النزهة جدة الرياض · سطحة السلامة جدة الرياض · سطحة الروضة
							جدة الرياض · سطحة من الرياض الى جدة · سطحة الرياض جدة · نقل سيارات بين
							المدن السعودية · خدمة نقل سيارات من الباب الى الباب · رقم سطحة جدة الرياض
						</p>
					</div>
				</div>

				<div className="mt-12 flex flex-col items-center justify-between gap-4 border-t border-white/10 pt-7 sm:flex-row">
					<p className="text-xs text-white/40">
						© {new Date().getFullYear()} سطحة جدة الرياض — جميع الحقوق محفوظة
					</p>
					<p className="text-xs text-white/40">
						نقل سيارات · سطحة مغلقة · هيدروليك · أسعار حسب المسافة
					</p>
				</div>
			</div>
		</footer>
	);
}

function FloatingActions() {
	const [showTop, setShowTop] = useState(false);

	useEffect(() => {
		const onScroll = () => setShowTop(window.scrollY > 500);
		window.addEventListener('scroll', onScroll, { passive: true });
		return () => window.removeEventListener('scroll', onScroll);
	}, []);

	return (
		<>
			<a
				href={PHONE_TEL}
				className="btn-coral phone-glow fixed bottom-6 left-6 z-40 hidden h-14 w-14 items-center justify-center rounded-full transition-transform hover:scale-105 active:scale-95 md:flex"
				aria-label="اتصل الآن بسطحة جدة الرياض"
			>
				<Phone className="relative h-6 w-6" strokeWidth={2.4} />
			</a>

			{showTop && (
				<button
					type="button"
					onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
					className="fixed bottom-6 right-6 z-40 flex h-12 w-12 items-center justify-center rounded-full border border-border bg-white text-foreground shadow-md transition-transform hover:scale-105"
					aria-label="العودة للأعلى"
				>
					<ArrowUp className="h-5 w-5" strokeWidth={2.4} />
				</button>
			)}

			<div className="fixed inset-x-0 bottom-0 z-40 border-t border-border bg-white/95 p-3 backdrop-blur md:hidden">
				<div className="mx-auto flex max-w-lg gap-2">
					<a
						href={PHONE_TEL}
						className="btn-coral flex min-h-[48px] flex-1 items-center justify-center gap-2 rounded-lg text-sm font-bold"
					>
						<Phone className="h-4 w-4" strokeWidth={2.4} />
						اتصل {PHONE_DISPLAY}
					</a>
					<a
						href={WHATSAPP_URL}
						target="_blank"
						rel="noopener noreferrer"
						className="flex min-h-[48px] flex-1 items-center justify-center gap-2 rounded-lg border-2 border-primary text-sm font-bold text-primary"
					>
						<MessageCircle className="h-4 w-4" strokeWidth={2.4} />
						واتساب
					</a>
				</div>
			</div>
		</>
	);
}

const PAGE_TITLE =
	'سطحة من جدة الى الرياض | نقل سيارات جدة إلى الرياض 24 ساعة';
const PAGE_DESC =
	'سطحة من جدة الى الرياض — نقل وشحن السيارات بسطحة هيدروليك ومغلقة وفل داون من جدة إلى الرياض. أسعار من 1000 ريال حسب المسافة (950 كم)، نقل آمن مؤمّن 24/7 من الباب إلى الباب. سطحة جدة الرياض 24 ساعة. اتصل 0550283132.';

export default function JeddahRiyadhPage() {
	return (
		<div className="min-h-screen bg-background text-foreground" dir="rtl" lang="ar">
			<Helmet>
				<html lang="ar" />
				<title>{PAGE_TITLE}</title>
				<meta name="description" content={PAGE_DESC} />
				<meta
					name="keywords"
					content="سطحة من جدة الى الرياض, سطحة جدة الرياض, سطحة نقل سيارات من جدة الى الرياض, سطحة جدة الرياض 24 ساعة, سطحة هيدروليك من جدة الى الرياض, سطحة مغلقة من جدة الى الرياض, سطحة فل داون من جدة الى الرياض, سطحة عادية من جدة الى الرياض, نقل سيارة من جدة الى الرياض, شحن سيارات من جدة الى الرياض, ارخص سطحة من جدة الى الرياض, سطحة من جدة الى الرياض 1000 ريال, سطحة من جدة الى الرياض 1100 ريال, سطحة من جدة الى الرياض 1800 ريال, سطحة من جدة الى الرياض 2000 ريال, كم سعر السطحة من جدة الى الرياض, تكلفة نقل سيارة من جدة الى الرياض, حجز سطحة من جدة الى الرياض, رقم سطحة من جدة الى الرياض, افضل سطحة من جدة الى الرياض, شركة سطحة من جدة الى الرياض, سطحة فورية من جدة الى الرياض, سطحة سيارات فارهة من جدة الى الرياض, سطحة سيارات رياضية من جدة الى الرياض, سطحة نقل سيارات تالفة جدة الرياض, سطحة نقل سيارات بدون تشغيل جدة الرياض, سطحة نقل جيب من جدة الى الرياض, سطحة نقل سيارات دفع رباعي جدة الرياض, سطحة الحمدانية جدة الرياض, سطحة أبحر جدة الرياض, سطحة الصفا جدة الرياض, سطحة النسيم جدة الرياض, سطحة المروة جدة الرياض, سطحة النزهة جدة الرياض, سطحة السلامة جدة الرياض, سطحة الروضة جدة الرياض, سطحة من الرياض الى جدة, سطحة الرياض جدة, نقل سيارات بين جدة والرياض, خدمة نقل سيارات من الباب الى الباب, نقل سيارات بين المدن السعودية"
				/>
			</Helmet>
			<Seo
				title={PAGE_TITLE}
				description={PAGE_DESC}
				image={HERO_IMG}
				siteName="سطحة جدة الرياض"
				type="website"
			/>
			<Header />
			<main>
				<Hero />
				<Services />
				<Pricing />
				<Areas />
				<CarTypes />
				<Transport />
				<Faq />
				<Contact />
			</main>
			<Footer />
			<FloatingActions />
		</div>
	);
}

# سطحة من جدة الى الرياض — Jeddah ⇄ Riyadh Vehicle Towing

موقع تسويقي (Landing Page) لخدمة نقل وسطحة السيارات بين جدة والرياض، مبني بـ React + Vite + Tailwind CSS.

A marketing landing page for a Jeddah ⇄ Riyadh vehicle towing & car-transport service, built with React + Vite + Tailwind CSS (RTL Arabic).

## المحتوى / Features

- صفحة واحدة مركّزة على خط جدة ⇄ الرياض (RTL عربي).
- أقسام: الواجهة (Hero)، أنواع السطحة، الأسعار، أحياء جدة والرياض، أنواع السيارات، النقل بين المدن، الأسئلة الشائعة، والحجز/التواصل.
- أنواع السطحة: عادية، هيدروليك (فل داون)، مغلقة.
- الأسعار: عادية 1000–1100 ريال · هيدروليك 1100–1300 ريال · مغلقة 1800–2000 ريال.
- مدة الرحلة التقريبية: 18–20 ساعة (مسافة ~950 كم).
- رقم التواصل: 0550283132 (اتصال مباشر + واتساب).
- الهيدر يحتوي اسم الموقع «سطحة جدة إلى الرياض» بجانب الشعار وزرّين فقط (اتصال + واتساب).
- بيانات وصفية (SEO) وبيانات منظمة (JSON-LD) لـ LocalBusiness / Service / FAQPage.

## التقنيات / Tech Stack

- React 18 + React Router
- Vite
- Tailwind CSS + shadcn/ui primitives
- framer-motion (scroll reveal)
- react-helmet (SEO meta)

## التشغيل محلياً / Run locally

```bash
# من جذر المشروع (monorepo)
npm install
npm run dev
```

ثم افتح المتصفح على المنفذ الافتراضي (عادة http://localhost:3000).

## البناء للإنتاج / Production build

```bash
npm run build
```

## الهيكل / Structure

```
.
├── apps/
│   └── web/                  # تطبيق الواجهة (React + Vite)
│       ├── index.html        # SEO metadata + JSON-LD
│       ├── public/           # manifest, robots, sitemap
│       ├── src/
│       │   ├── App.jsx       # التوجيه (Routes)
│       │   ├── main.jsx      # نقطة الدخول
│       │   ├── index.css     # ثيم Tailwind + المتغيرات + الأنماط المخصصة
│       │   ├── pages/JeddahRiyadhPage.jsx
│       │   ├── components/   # Reveal, Seo, ScrollToTop, ui/*
│       │   ├── hooks/
│       │   └── lib/
│       ├── tailwind.config.js
│       ├── vite.config.js
│       └── package.json
├── package.json              # monorepo root
└── package-lock.json
```

## ملاحظة / Note

هذا المستودع يحتوي كود الموقع فقط. لا يحتوي على بيانات حساسة أو مفاتيح.
